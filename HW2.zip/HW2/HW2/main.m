//
//  main.m
//  HW2
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"HW2AppDelegate");
    [pool release];
    return retVal;
}
