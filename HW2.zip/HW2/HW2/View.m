//
//  View.m
//  HW2
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "View.h"


@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor grayColor];
		
		CGRect f = CGRectMake(0, 0, 40, 40);
		view = [[UIView alloc] initWithFrame: f];
		view.backgroundColor = [UIColor purpleColor];
		[self addSubview: view];
        
        CGRect b = self.bounds;
        
		self.bounds = CGRectMake(
                                 -b.size.width / 2,
                                 -b.size.height / 2,
                                 b.size.width,
                                 b.size.height
                                 );
    }
    return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
        
		[UIView animateWithDuration: 1.0
                              delay: 0.0
                            options: UIViewAnimationOptionCurveEaseInOut
                         animations: ^{
                             //This block describes what the animation should do.
                             	[UIView setAnimationRepeatCount: 1];
                             view.center = [[touches anyObject] locationInView: self];
                        
                             view.alpha = 1.0;	//0.0 is transparent, 1.0 is opaque
                             b = !b;		
                             
                             if (b) {
                                 view.backgroundColor = [UIColor blackColor];
                                 view.transform = CGAffineTransformMakeScale(4, 4);
                             } else {
                                 view.backgroundColor = [UIColor purpleColor];
                                 view.transform = CGAffineTransformMakeScale(1, 1);
                             }

                         }
                         completion: NULL
         ];
	}
}



		
		//Can combine the above three statements to
		//view.center = [[touches anyObject] locationInView: self];




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
         [view release];
    [super dealloc];
}

@end
