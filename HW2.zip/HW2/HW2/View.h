//
//  View.h
//  HW2
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
    UIView *view;
    BOOL b;
}

@end
