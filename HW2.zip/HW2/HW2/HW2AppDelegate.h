//
//  HW2AppDelegate.h
//  HW2
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface HW2AppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
    UIWindow *window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
