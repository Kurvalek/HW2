//
//  HW2Tests.m
//  HW2Tests
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "HW2Tests.h"


@implementation HW2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HW2Tests");
}

@end
