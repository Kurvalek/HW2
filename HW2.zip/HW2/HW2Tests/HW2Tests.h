//
//  HW2Tests.h
//  HW2Tests
//
//  Created by Kathleen Urvalek on 7/6/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HW2Tests : SenTestCase {
@private
    
}

@end
